let composites n =
  let composites = Array.init n (fun x -> 0) in
  let sqrtn = int_of_float @@ sqrt @@ float_of_int n in
  for i = 2 to sqrtn do
      for j = 2 to n / i do
        composites.(i*j - 1) <- i * j;
      done;
  done;
  composites
